package com.example.myastjson_v3.Dates

import android.util.Log
import android.util.Log.d
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@JsonClass(generateAdapter = true) // Генерирует код адаптера при сборке
data class RootObject(
    val id: Int,
    val name: String,
    val long_name: String = "",
    var modeTU: Int = 0, // 0- Default нет связи, 1- Авто, 2- Руч.Вкл, 3- Руч.Откл,
    var status: Boolean = false, // вкл пускатель или нет
    val status_alarm: Boolean = false,
    var elements: List<Element>,
)

data class MapPoint(
//    для координат Широта и Долгота
    val N: String = "",
    val W: String = "",
)

@JsonClass(generateAdapter = true) // Генерирует код адаптера при сборке
data class Element(
    val idp: Int,
    val namep: String,
    val modeWork: Boolean, //  false -ОТКЛ , true - ВКЛ
    val setpoint_light_point: Float = 0.0f, // точка установки
    val status_light_point: Int = 0, // 0-нет питания, 1-вкл, 2-откл
    val status_alarmElement: Boolean = false,
    val map_point_id: MapPoint = MapPoint("0", "0"),
)

/*
@JsonClass(generateAdapter = true)
data class RootObject(
    @Json(name = "0") val id: Int,
    @Json(name = "1") val name: String,
    @Json(name = "2") val mode: Int,
    // Указываем значение по умолчанию, чтобы не падать, если поля нет в JSON
    @Json(name = "3") val elements: List<Element> = emptyList(),
    @Json(name = "4") val status: Boolean = false
)
И тогда JSON должен быть таким:
[
  {
    "0": 1,
    "1": "ТП 1",
    "2": 0,
    "3": []
  }
]
 */

val rootSTR = """
[
  {
    "id": 1,
    "name": "ТП 1",
    "long_name": "ТП 1",
    "modeTU": 1,
    "status": true,
    "status_alarm": false,
    "elements": [
      {
        "idp": 1,
        "namep": "sv160.1",
        "modeWork": true,
        "status_alarmElement": true,
        "status_light_point" : 0
      },
      {
        "idp": 2,
        "namep": "sv160.2",
        "modeWork": false,
        "status_alarmElement": false,
        "status_light_point" : 0
      },
      {
        "idp": 3,
        "namep": "sv160.3",
        "modeWork": false,
        "status_alarmElement": false,
        "status_light_point" : 1
      },
      {
        "idp": 4,
        "namep": "sv160.4",
        "modeWork": false,
        "status_alarmElement": false,
        "status_light_point" : 2
      }
    ]
  },
  {
    "id": 2,
    "name": "ТП 2",
    "long_name": "ТП 2",
    "modeTU": 0,
    "status_alarm": true,
    "elements": [
      {
        "idp": 1,
        "namep": "sv160.1",
        "modeWork": false,
        "status_alarmElement": true,
        "status_light_point": 0
      },
      {
        "idp": 2,
        "namep": "sv160.2",
        "modeWork": false,
        "status_alarmElement": true,
        "status_light_point" : 1
      }
    ]
  }
]
"""


class RootJson : ViewModel() {

    val rootList = mutableStateListOf<RootObject>() // список объектов RootObject


    init{
        this.readRoot()
    }

    fun readRoot() {
        val parsedData = parseData(rootSTR)
        if (parsedData != null) {
            // Чтобы не дублировать данные при повторном нажатии
            rootList.clear()
            rootList.addAll(parsedData)
        }
    }

    fun getRoot(): RootObject? = rootList.firstOrNull()

    fun getRootById(id: Int): RootObject? {
        return rootList.find { it.id == id }
    }

    fun setStatusOn(id: Int) {
        Log.d("setStatus", "Начинаем обновление для ID $id")
        // 1. Находим индекс
        val index = rootList.indexOfFirst { it.id == id }
        if (index != -1) {
            // Получаем текущий объект
            val currentRoot = rootList[index]
            // 2. СОЗДАЕМ НОВЫЙ СПИСОК ЭЛЕМЕНТОВ
            // Метод .map создаст новый список, где у каждого элемента будет вызван .copy
            val updatedElements = currentRoot.elements.map { element ->
                element.copy(modeWork = true)
            }
            // 3. ОБНОВЛЯЕМ ВЕСЬ КОРНЕВОЙ ОБЪЕКТ
            // Мы передаем и новый статус, и новый список элементов одновременно
            rootList[index] = currentRoot.copy(
                modeTU = 1,
                status = true,
                elements = updatedElements as MutableList<Element>
            )
            Log.d("setStatus", "Объект $id и все его элементы (${updatedElements.size}) обновлены!")
        }
    }

    fun setStatusOff(id: Int) {
        // 1. Находим индекс
        val index = rootList.indexOfFirst { it.id == id }
        if (index != -1) {
            // Получаем текущий объект
            val currentRoot = rootList[index]
            // 2. СОЗДАЕМ НОВЫЙ СПИСОК ЭЛЕМЕНТОВ
            // Метод .map создаст новый список, где у каждого элемента будет вызван .copy
            val updatedElements = currentRoot.elements.map { element ->
                element.copy(modeWork = false)
            }
            // 3. ОБНОВЛЯЕМ ВЕСЬ КОРНЕВОЙ ОБЪЕКТ
            // Мы передаем и новый статус, и новый список элементов одновременно
            rootList[index] = currentRoot.copy(
                modeTU = 2,
                status = false,
                elements = updatedElements as MutableList<Element>
            )
            Log.d("setStatus", "Объект $id и все его элементы (${updatedElements.size}) обновлены!")
        }
    }

    fun setOnlyOn(rootId: Int) {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            rootList[rootIndex] = rootList[rootIndex].copy(modeTU = 1, status = true)
        }
    }

    fun setOnlyOff(rootId: Int) {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            rootList[rootIndex] = rootList[rootIndex].copy(modeTU = 2, status = false)
        }
    }


    // один элемент управления ВКЛ
    fun toggleElementWorkOn(rootId: Int, elementId: Int) {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {

            val updatedElements = rootList[rootIndex].elements.map { el ->
                if (el.idp == elementId) el.copy(modeWork = true) else el
            }
            rootList[rootIndex] =
                rootList[rootIndex].copy(elements = updatedElements as MutableList<Element>)
            setOnlyOn(rootId)
        }
    }

    // один элемент управления ВКЛ
    fun toggleElementWorkOff(rootId: Int, elementId: Int) {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            val updatedElements = rootList[rootIndex].elements.map { el ->
                if (el.idp == elementId) el.copy(modeWork = false) else el
            }
            rootList[rootIndex] =
                rootList[rootIndex].copy(elements = updatedElements as MutableList<Element>)
        }
        setOnlyOff(rootId)
    }
    // ################################# GET #######################################
    // берем объект по ID из элемента и возвращаем его
    fun getElement(rootId: Int, elementId: Int): Element? {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            return rootList[rootIndex].elements.find { it.idp == elementId }
        }
        return null
    }
    fun getAlarms(rootId: Int): Boolean {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            return rootList[rootIndex].status_alarm
    }
        return false
    }
    fun getAlarmCount(rootId: Int): Int {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            return rootList[rootIndex].elements.count { it.status_alarmElement }
        }
        return 0
    }
    fun getVklCount(rootId: Int): Int {
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            return rootList[rootIndex].elements.count { it.modeWork }
        }
        return 0
    }
    fun getSvetElementCount(rootId: Int): Int { // 0-нет питания, 1-вкл, 2-откл
        val rootIndex = rootList.indexOfFirst { it.id == rootId }
        if (rootIndex != -1) {
            return rootList[rootIndex].elements.count { it.status_light_point == 0 }
        }
        return 0
    }
    // ############# TEST ELEMENT ALARM is LIST ############################
    fun testAlarms(id: Int): List<Element> {
        val rootIndex = rootList.indexOfFirst { it.id == id }
        Log.i("!!!", "testAlarms: ${rootIndex}, ${rootList[rootIndex].name}" )
        if (rootIndex != -1) {
            return rootList[rootIndex].elements.filter { it.status_alarmElement }
        }
        return emptyList()
    }
    fun testModeWork(id: Int): List<Element> {
        val rootIndex = rootList.indexOfFirst { it.id == id }
        if (rootIndex != -1) {
            return rootList[rootIndex].elements.filter { it.modeWork }
        }
        return emptyList()
    }

/*
// 1. Все вложенные элементы с условием
rootList.flatMap { it.elements }.filter { it.status_alarmElement }

// 2. Родители где есть хотя бы 1 alarm
rootList.filter { it.elements.any { it.status_alarmElement } }

// 3. Количество alarm'ов в каждом родителе
rootList.map { it to it.elements.count { it.status_alarmElement } }

// 4. Только alarm элементы (коротко)
rootList.flatMap { it.elements.filter { it.status_alarmElement } }
 */

}
    // ################################# JSON #######################################
fun parseData(jsonString: String): List<RootObject>? {  // парсит JSON
    d("parseData", "parseData")

    val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    // Описываем тип: List<RootObject>
    val listType = Types.newParameterizedType(List::class.java, RootObject::class.java)

    //    Создаем адаптер для этого типа
    val adapter = moshi.adapter<List<RootObject>>(listType)
    //    Парсим JSON
    return try {
        adapter.fromJson(jsonString)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }

}

/*
Как это выглядит в работе (логика)
Представьте, что Moshi работает как почтовый сортировщик:
Он видит внешний символ [ — понимает, что это List.
Внутри списка видит { — понимает, что это объект RootObject.
Читает id, name, modeTU.
Доходит до ключа "elements": [ — он видит, что в модели это List<Element2>,
 поэтому временно переключается на создание объектов Element2.
Заполнив список elements, он возвращается к сборке RootObject.
 */