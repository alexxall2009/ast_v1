package com.example.myastjson_v3.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)


// --- Цветовая палитра проекта ---
val BgScreen = Color(213, 213, 213)
val BgControlActive = Color(243, 243, 243)
val BluePrimary = Color(0, 0, 215)
val GrayBorder = Color(160, 160, 160)
val GraySelection = Color(225, 225, 225)
val GrayText = Color(100, 100, 100)
val DarkText = Color(40, 40, 40)
val OrangeP3 = Color(255, 102, 0)
val GreenSetPoint = Color(0, 128, 0)


val MylightGray = Color(100, 100, 100, 27)
val MyBluePrimary = Color(62, 62, 208, 255)

// фон
val MyFonColorGrey: Color = Color(red = 213, green = 213, blue = 213, alpha = 141)
//текст
val MyTextColor: Color = Color(red = 45, green = 45, blue = 45, alpha = 255)
//кнопки
val MyButtonColor: Color = Color(red = 190, green = 190, blue = 190, alpha = 255)
// цвет иконки
val MyIconColor: Color = Color(red = 255, green = 255, blue = 255, alpha = 255)
// для barof
val MyBarColor: Color = Color(red = 136, green = 136, blue = 136, alpha = 72)
// Mysurface
val Mysurface: Color = Color(red = 255, green = 255, blue = 255, alpha = 255)


val MyGrey: Color = Color(red = 136, green = 136, blue = 136, alpha = 255)
val MyDarkBlue: Color = Color(red = 0, green = 0, blue = 215, alpha = 255)
val MyHelpText: Color = Color(red = 158, green = 158, blue = 158, alpha = 255)
val MyYellow: Color = Color(red = 255, green = 255, blue = 0, alpha = 255)
val MyBlue: Color = Color(0xFF1D60EC)
val MyRed: Color = Color(0xFFEC1D70)
val MyBlack: Color = Color(0xFF0C0C0C)
val MyGreen: Color = Color(0xFF00FF00)
