package com.example.myastjson_v3.Screens.Screen1.Screen2.Screen3

import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButtonDefaults.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.myastjson_v3.Dates.Element
import com.example.myastjson_v3.Dates.RootJson
import com.example.myastjson_v3.ui.theme.BgScreen
import com.example.myastjson_v3.ui.theme.OrangeP3


@Composable
fun Screen3ListItems(rootId: Int, viewModel: RootJson, onBack: () -> Unit) {

    // Находим объект по ID
    val rootObject = viewModel.getRootById(rootId) // берем объект из viewModel
    val Alarm = viewModel.getAlarmCount(rootId) // берем количество аварий из viewModel
    val allElements = rootObject?.elements?.size ?: 0 // берем количество элементов из viewModel
    val Vkl = viewModel.getVklCount(rootId) // берем количество включенных элементов из viewModel
    val Svet =
        viewModel.getSvetElementCount(rootId) // берем количество включенных элементов из viewModel
    // test Alarm
//    val alarmList = viewModel.testAlarms(rootId) пока не так
//    val modeWorkList = viewModel.testModeWork(rootId) пока не так

    // создаем список элементов по группам
    val goupList = rootObject?.elements?.groupBy {
        when {
            it.status_alarmElement -> "🚨 АВАРИИ"
            it.modeWork -> "🔴 НЕАКТИВНЫЕ"
            else -> "Общие"
        }
    }
//     для открытия всех элементов или закрытия групп
    val expandState = remember {
        mutableStateMapOf<String, Boolean>().apply {
            goupList?.keys?.forEach { key -> this[key] = true }
        }
    }




    Scaffold(
        modifier = Modifier
            .padding(top = 16.dp)
            .fillMaxSize(),
        topBar = { TopBar(Alarm, Vkl, Svet, allElements) },
        bottomBar = { Text("Нижняя панель") }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BgScreen),
        ) {

            Text("Секция 3: Список элементов свето-точек")
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                goupList?.onEach { (groupName, elements) ->
                    val expanded = expandState[groupName] ?: true  // для определения на какую группу нажал
                    // Заголовок (stickyHeader)
                    stickyHeader(key = groupName) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.LightGray)
                                .clickable{expandState[groupName] = !expanded}
                        ) {
                           // функция заоловка
                            Text(groupName, modifier = Modifier.padding(start = 16.dp))
                            Text(
                                " элементов: ${elements.size}",
                                modifier = Modifier.padding(start = 16.dp)
                            )
                        }
                    }
                    // сам список элементов будет отображаться только при нажатии на заголовок
                    if (expanded) {
                        items(elements, key = { it.idp }) { element ->
                            ElementCard(element, onItemClick = {
                                Log.i("!!!", "ScreenListToCard -> onClick: ${element.idp}")
                            } )
                        }
                    }
                }
            }


        }
    }
}

@Composable
fun ElementCard(element: Element, onItemClick: () -> Unit) {

    val statusAlarmColor =  if (element.status_alarmElement) Color.Red else Color.White
    val statusLightPoint = when (element.status_light_point) {
        0 -> "Нет питания"
        1 -> "Вкл"
        2 -> "Откл"
        else -> ""
    }
    val statusLightPointColor = when (element.status_light_point) {
        0 -> Color.Red
        1 -> OrangeP3
        2 -> Color.Green
        else -> Color.Black
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ){
        Column(modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center){
            Row(verticalAlignment = Alignment.CenterVertically
            ){
                Text("Name: ${element.namep}")
                Spacer(modifier = Modifier.width(8.dp))
                if (element.status_alarmElement) {
                    Icon(Icons.Filled.Alarm, contentDescription = "Alarm", tint = statusAlarmColor)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(statusLightPoint, color = statusLightPointColor)

            }
        }
    }
}


@Composable
fun TopBar(alarmCount: Int = 0, Vkl: Int = 0, Svet: Int = 0, allElements: Int = 0) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.LightGray),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text("Авария")
                Text("${alarmCount}/${allElements}")
            }

        }
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text("Вкл")
                Text("${Vkl}/${allElements}")
            }
        }
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text("Связь")
                Text("${Svet}/${allElements}")
            }
        }
    }
}





