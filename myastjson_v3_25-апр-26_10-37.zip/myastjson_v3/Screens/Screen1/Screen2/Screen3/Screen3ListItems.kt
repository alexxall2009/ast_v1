package com.example.myastjson_v3.Screens.Screen1.Screen2.Screen3

import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.myastjson_v3.Dates.RootJson
import com.example.myastjson_v3.Screens.Screen1.ScreenLevel1
import com.example.myastjson_v3.ui.theme.BgScreen


@Composable
fun Screen3ListItems(rootId: Int, viewModel: RootJson, onBack: () -> Unit) {

    // Находим объект по ID
    val rootObject = viewModel.getRootById(rootId) // берем объект из viewModel

    Scaffold(
        modifier = Modifier
            .padding(top = 16.dp)
            .fillMaxSize(),
        topBar = { TopBar() },
        bottomBar = { Text("Нижняя панель") }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BgScreen),
        ) {

            Text("Секция 3: Список элементов свето-точек")
            LazyVerticalGrid(
                columns = GridCells.Fixed(1), // 2 колонки, как ты и хотел
                modifier = Modifier.fillMaxSize(),
                // 1. Обязательно указывай отступы здесь, а не внутри карточек
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(
                    items = rootObject?.elements.orEmpty(),
                    // 2. КЛЮЧ — это спасение. Позволяет не перерисовывать всё при обновлении списка
                    key = { _, item -> item.idp },
                    // 3. ТИП КОНТЕНТА — помогает системе переиспользовать верстку карточек
                    contentType = { _, _ -> "RootCard" }
                ) { index, elementPoint ->
                    Column {
                        ScreenListToCard(
                            vm = viewModel,
                            id = elementPoint.idp,
                            onItemClick = { id ->
                                Log.i("!!!", "Клик по $id")
                            }
                        )
                    }
                }


            }
        }
    }
}

@Composable
fun TopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Red),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Авария 0/0")
        }
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) { Text("Вкл 0/0") }
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) { Text("Откл 0/0") }
    }
}


@Composable
fun ScreenListToCard(vm: RootJson, id: Int, onItemClick: (Int) -> Unit) {

    val elementPoint = vm.getElement(id, id) // берем элемент из viewModel

    Text("ID: $id")
    Card(onClick = {
        Log.i("!!!", "ScreenListToCard -> onClick: $id")
//        onItemClick(id)
    }) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ){
            Text("Элемент: $id")
            Text("Статус: ${elementPoint?.modeWork}")
        }
    }


}

