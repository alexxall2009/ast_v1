package com.example.myastjson_v3.Screens.Screen1.Screen2.Screen3

import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.myastjson_v3.Dates.Element
import com.example.myastjson_v3.Dates.RootJson
import com.example.myastjson_v3.Screens.Screen1.ScreenLevel1
import com.example.myastjson_v3.ui.theme.BgScreen


@Composable
fun Screen3ListItems(rootId: Int, viewModel: RootJson, onBack: () -> Unit) {

    // Находим объект по ID
    val rootObject = viewModel.getRootById(rootId) // берем объект из viewModel
    val Alarm = viewModel.getAlarmCount(rootId) // берем количество аварий из viewModel
    val allElements = rootObject?.elements?.size ?: 0 // берем количество элементов из viewModel
    val Vkl = viewModel.getVklCount(rootId) // берем количество включенных элементов из viewModel
    val Svet =
        viewModel.getSvetElementCount(rootId) // берем количество включенных элементов из viewModel
    // test Alarm
    val alarmList = viewModel.testAlarms(rootId)
    val modeWorkList = viewModel.testModeWork(rootId)
    val goupList = rootObject?.elements?.groupBy {
        when {
            it.status_alarmElement -> "🚨 АВАРИИ"
            it.modeWork -> "🔴 НЕАКТИВНЫЕ"

            else -> "else"
        }
    }


    Scaffold(
        modifier = Modifier
            .padding(top = 16.dp)
            .fillMaxSize(),
        topBar = { TopBar(Alarm, Vkl, Svet, allElements) },
        bottomBar = { Text("Нижняя панель") }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BgScreen),
        ) {

            Text("Секция 3: Список элементов свето-точек")
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                goupList?.forEach { status, elements ->
                    stickyHeader(key = status) {
                        CategoryHeader(
                            title = status,
                            count = elements.size,
                            color = getStatusColor(status)
                        )
                    }
                    items(elements, key = { it.idp }) { element ->
                        StatusItem(element)
                    }
                }
            }


        }
    }
}

fun getStatusColor(status: String): Color = when {
    status.contains("АВАРИИ") -> Color.Red
    status.contains("АКТИВНЫЕ") -> Color.Green
    else -> Color.Gray
}


@Composable
fun TopBar(alarmCount: Int = 0, Vkl: Int = 0, Svet: Int = 0, allElements: Int = 0) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.LightGray),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text("Авария")
                Text("${alarmCount}/${allElements}")
            }

        }
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text("Вкл")
                Text("${Vkl}/${allElements}")
            }
        }
        Button(
            onClick = { /* действие */ },
            modifier = Modifier.padding(6.dp),
            // Правильный способ задать цвет фона и текста кнопки
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Red // Текст сделаем красным, раз это "Авария"
            ),
            // Добавим рамку, чтобы белая кнопка не сливалась с фоном
            border = BorderStroke(1.dp, Color.LightGray),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text("Связь")
                Text("${Svet}/${allElements}")
            }
        }
    }
}


@Composable
fun CategoryHeader(
    title: String,
    color: Color,
    count: Int,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color, CircleShape)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "$count",
                style = MaterialTheme.typography.titleSmall,
                color = color,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ScreenListToCard(vm: RootJson, id: Int, onItemClick: (Int) -> Unit) {
    val elementPoint = vm.getElement(id, id) // берем элемент из viewModel
    Card(onClick = {
        Log.i("!!!", "ScreenListToCard -> onClick: $id")
//        onItemClick(id)
    }) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text("Элемент: $id")
            Text("modeWork: ${elementPoint?.modeWork}")
            Text("status_alarmElement: ${elementPoint?.status_alarmElement}")
        }
    }


}

@Composable
fun StatusItem(x0: Element) {
    Text("Элемент: ${x0.idp}")
    Text("Элемент: ${x0.namep}")
}

